/*
 * mutex.h
 *
 *  Created on: 8 may. 2018
 *      Author: Alejo
 */

#ifndef MUTEX_H_
#define MUTEX_H_


void lock (int key);
void unlock (int key);



#endif /* MUTEX_H_ */
